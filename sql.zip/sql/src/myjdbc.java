import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.*;

public class myjdbc {


    public static void main(String[] args) {
        try{

        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/students", "root", "Jude2004@");

        Statement statement = connection.createStatement();

        ResultSet resultset = statement.executeQuery("select * from student");

        while (resultset.next()) {
            System.out.println(resultset.getString("STUDENT_NAME"));
//
        }
    }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
