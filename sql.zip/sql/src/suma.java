import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class suma {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/students";
    private static final String USER = "root";
    private static final String PASSWORD = "Jude2004@";

    private Connection connection;
    private JFrame frame;
    private JTextArea retrieveTextArea;

    public suma() {
        try {
            connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            System.exit(1);
        }
        createAndShowGUI();
    }

    private void createAndShowGUI() {
        frame = new JFrame("Student Registration GUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JPanel insertPanel = createInsertPanel();
        JPanel deletePanel = createDeletePanel();
        JPanel updatePanel = createUpdatePanel();
        JPanel retrievePanel = createRetrievePanel();

        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 5, 5));
        JButton insertButton = new JButton("Insert");
        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPanel(insertPanel);
            }
        });
        buttonPanel.add(insertButton);

        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPanel(deletePanel);
            }
        });
        buttonPanel.add(deleteButton);

        JButton updateButton = new JButton("Update");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPanel(updatePanel);
            }
        });
        buttonPanel.add(updateButton);

        JButton retrieveButton = new JButton("Retrieve");
        retrieveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPanel(retrievePanel);
                retrieveData();
            }
        });
        buttonPanel.add(retrieveButton);

        frame.add(buttonPanel, BorderLayout.NORTH);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void showPanel(JPanel panel) {
        frame.getContentPane().removeAll();
        frame.add(panel, BorderLayout.CENTER);
        frame.revalidate();
        frame.repaint();
    }

    private JPanel createInsertPanel() {
        JPanel panel = new JPanel(new GridLayout(6, 2, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Insert panel components
        // ...

        return panel;
    }

    private JPanel createDeletePanel() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Delete panel components
        // ...

        return panel;
    }

    private JPanel createUpdatePanel() {
        JPanel panel = new JPanel(new GridLayout(6, 2, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Update panel components
        // ...

        return panel;
    }

    private JPanel createRetrievePanel() {
        JPanel panel = new JPanel(new BorderLayout());

        retrieveTextArea = new JTextArea(10, 40);
        retrieveTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(retrieveTextArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private void insertData(int id, String name, int age, String gender, String department) {
        // Insert data logic
    }

    private void deleteData(int id) {
        // Delete data logic
    }

    private void updateData(int id, String name, int age, String gender, String department) {
        // Update data logic
    }

    private void retrieveData() {
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM student");

            StringBuilder stringBuilder = new StringBuilder();
            while (resultSet.next()) {
                stringBuilder.append("Student ID: ").append(resultSet.getInt("STUDEN_ID")).append("\n");
                stringBuilder.append("Student Name: ").append(resultSet.getString("STUDENT_NAME")).append("\n");
                stringBuilder.append("Age: ").append(resultSet.getInt("STUDENT_AGE")).append("\n");
                stringBuilder.append("Gender: ").append(resultSet.getString("GNEDER")).append("\n");
                stringBuilder.append("Department: ").append(resultSet.getString("DEPARTMENT")).append("\n\n");
            }

            retrieveTextArea.setText(stringBuilder.toString());

            resultSet.close();
            statement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new studentydf();
            }
        });
    }
}
