import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class gui {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/students";
    private static final String USER = "root";
    private static final String PASSWORD = "Jude2004@";

    private Connection connection;
    private JFrame frame;

    public gui() {
        try {
            connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to connect to the database.", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        createAndShowGUI();
    }

    private void createAndShowGUI() {
        frame = new JFrame("Student Registration GUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JPanel insertPanel = createInsertPanel();
        JPanel deletePanel = createDeletePanel();
        JPanel updatePanel = createUpdatePanel();
        JPanel retrievePanel = createRetrievePanel();

        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 5, 5));
        JButton insertButton = new JButton("Insert");
        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPanel(insertPanel);
            }
        });
        buttonPanel.add(insertButton);

        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPanel(deletePanel);
            }
        });
        buttonPanel.add(deleteButton);

        JButton updateButton = new JButton("Update");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPanel(updatePanel);
            }
        });
        buttonPanel.add(updateButton);

        JButton retrieveButton = new JButton("Retrieve");
        retrieveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPanel(retrievePanel);
                retrieveData();
            }
        });
        buttonPanel.add(retrieveButton);

        frame.add(buttonPanel, BorderLayout.NORTH);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void showPanel(JPanel panel) {
        frame.getContentPane().removeAll();
        frame.add(panel, BorderLayout.CENTER);
        frame.revalidate();
        frame.repaint();
    }

    private JPanel createInsertPanel() {
        JPanel panel = new JPanel(new GridLayout(6, 2, 5, 5));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Insert Student"),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        panel.add(new JLabel("Student ID:"));
        JTextField idField = new JTextField();
        panel.add(idField);

        panel.add(new JLabel("Student Name:"));
        JTextField nameField = new JTextField();
        panel.add(nameField);

        panel.add(new JLabel("Age:"));
        JTextField ageField = new JTextField();
        panel.add(ageField);

        panel.add(new JLabel("Gender:"));
        JTextField genderField = new JTextField();
        panel.add(genderField);

        panel.add(new JLabel("Department:"));
        JTextField deptField = new JTextField();
        panel.add(deptField);

        JButton insertButton = new JButton("Insert");
        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(idField.getText());
                    String name = nameField.getText();
                    int age = Integer.parseInt(ageField.getText());
                    String gender = genderField.getText();
                    String department = deptField.getText();

                    insertData(id, name, age, gender, department);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Please enter valid data.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        panel.add(insertButton);

        return panel;
    }

    private JPanel createDeletePanel() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Delete Student"),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        panel.add(new JLabel("Enter Student ID to delete:"));
        JTextField idField = new JTextField();
        panel.add(idField);

        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(idField.getText());
                    deleteData(id);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Please enter valid ID.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        panel.add(deleteButton);

        return panel;
    }

    private JPanel createUpdatePanel() {
        JPanel panel = new JPanel(new GridLayout(6, 2, 5, 5));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Update Student"),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        panel.add(new JLabel("Student ID to update:"));
        JTextField idField = new JTextField();
        panel.add(idField);

        panel.add(new JLabel("New Student Name:"));
        JTextField nameField = new JTextField();
        panel.add(nameField);

        panel.add(new JLabel("New Age:"));
        JTextField ageField = new JTextField();
        panel.add(ageField);

        panel.add(new JLabel("New Gender:"));
        JTextField genderField = new JTextField();
        panel.add(genderField);

        panel.add(new JLabel("New Department:"));
        JTextField deptField = new JTextField();
        panel.add(deptField);

        JButton updateButton = new JButton("Update");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(idField.getText());
                    String name = nameField.getText();
                    int age = Integer.parseInt(ageField.getText());
                    String gender = genderField.getText();
                    String department = deptField.getText();

                    updateData(id, name, age, gender, department);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Please enter valid data.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        panel.add(updateButton);

        return panel;
    }

    private JPanel createRetrievePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Retrieve Students"),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        JTextArea textArea = new JTextArea(10, 30);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        JButton retrieveButton = new JButton("Retrieve");
        retrieveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder stringBuilder = new StringBuilder();
                try {
                    Statement statement = connection.createStatement();
                    ResultSet resultSet = statement.executeQuery("SELECT * FROM student");
                    while (resultSet.next()) {
                        stringBuilder.append("Student ID: ").append(resultSet.getInt("STUDEN_ID")).append("\n");
                        stringBuilder.append("Student Name: ").append(resultSet.getString("STUDENT_NAME")).append("\n");
                        stringBuilder.append("Age: ").append(resultSet.getInt("STUDENT_AGE")).append("\n");
                        stringBuilder.append("Gender: ").append(resultSet.getString("GNEDER")).append("\n");
                        stringBuilder.append("Department: ").append(resultSet.getString("DEPARTMENT")).append("\n\n");
                    }
                    textArea.setText(stringBuilder.toString());
                    resultSet.close();
                    statement.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        panel.add(retrieveButton, BorderLayout.SOUTH);

        return panel;
    }

    private void insertData(int id, String name, int age, String gender, String department) {
        try {
            String insertQuery = "INSERT INTO student (STUDEN_ID, STUDENT_NAME, STUDENT_AGE, GNEDER, DEPARTMENT) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setInt(1, id);
            preparedStatement.setString(2, name);
            preparedStatement.setInt(3, age);
            preparedStatement.setString(4, gender);
            preparedStatement.setString(5, department);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(frame, "Data inserted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "Failed to insert data.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteData(int id) {
        try {
            String deleteQuery = "DELETE FROM student WHERE STUDEN_ID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
            preparedStatement.setInt(1, id);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(frame, "Data deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "No data found to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateData(int id, String name, int age, String gender, String department) {
        try {
            String updateQuery = "UPDATE student SET STUDENT_NAME = ?, STUDENT_AGE = ?, GNEDER = ?, DEPARTMENT = ? WHERE STUDEN_ID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, age);
            preparedStatement.setString(3, gender);
            preparedStatement.setString(4, department);
            preparedStatement.setInt(5, id);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(frame, "Data updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "No data found to update.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void retrieveData() {
        // Retrieve logic is implemented in createRetrievePanel()
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new StudentRegistrationGUI();
            }
        });
    }
}
