import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class ProductManagementApp extends JFrame {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shop_managemNEt";
    private static final String USER = "root";
    private static final String PASS = "Jude2004@";

    public ProductManagementApp() {
        super("Product Management App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(5, 1));

        JButton insertButton = new JButton("Insert Product");
        JButton deleteButton = new JButton("Delete Product");
        JButton retrieveButton = new JButton("Retrieve Products");
        JButton updateButton = new JButton("Update Product");
        JButton checkExpiredButton = new JButton("Check Expired Products");

        insertButton.addActionListener(e -> new InsertProductFrame().setVisible(true));
        deleteButton.addActionListener(e -> new DeleteProductFrame().setVisible(true));
        retrieveButton.addActionListener(e -> new RetrieveProductsFrame().setVisible(true));
        updateButton.addActionListener(e -> new UpdateProductFrame().setVisible(true));
        checkExpiredButton.addActionListener(e -> new CheckExpiredProductsFrame().setVisible(true));

        add(insertButton);
        add(deleteButton);
        add(retrieveButton);
        add(updateButton);
        add(checkExpiredButton);
    }

    // Frame for inserting products
    private class InsertProductFrame extends JFrame {
        JTextField productNameField, categoryField, quantityField, priceField, manufactureDateField, expiryDateField;

        public InsertProductFrame() {
            super("Insert Product");
            setSize(400, 300);
            setLocationRelativeTo(null);
            setLayout(new GridLayout(7, 2));

            productNameField = new JTextField();
            categoryField = new JTextField();
            quantityField = new JTextField();
            priceField = new JTextField();
            manufactureDateField = new JTextField();
            expiryDateField = new JTextField();

            add(new JLabel("Product Name:"));
            add(productNameField);
            add(new JLabel("Category:"));
            add(categoryField);
            add(new JLabel("Quantity:"));
            add(quantityField);
            add(new JLabel("Price:"));
            add(priceField);
            add(new JLabel("Manufacture Date (yyyy-mm-dd):"));
            add(manufactureDateField);
            add(new JLabel("Expiry Date (yyyy-mm-dd):"));
            add(expiryDateField);

            JButton insertButton = new JButton("Insert");
            insertButton.addActionListener(e -> insertProduct());
            add(insertButton);
        }

        private void insertProduct() {
            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
                String productName = productNameField.getText();
                String category = categoryField.getText();
                int quantity = Integer.parseInt(quantityField.getText());
                double price = Double.parseDouble(priceField.getText());
                String manufactureDate = manufactureDateField.getText();
                String expiryDate = expiryDateField.getText();

                String sql = "INSERT INTO PRODUCTS1234 (productname, category, quantity, price, date_of_manufacture, date_of_expiry) " +
                        "VALUES (?, ?, ?, ?, ?, ?)";

                try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                    pstmt.setString(1, productName);
                    pstmt.setString(2, category);
                    pstmt.setInt(3, quantity);
                    pstmt.setDouble(4, price);
                    pstmt.setDate(5, Date.valueOf(manufactureDate));
                    pstmt.setDate(6, Date.valueOf(expiryDate));
                    pstmt.executeUpdate();

                    JOptionPane.showMessageDialog(this, "Product inserted successfully.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    // Frame for deleting products
    private class DeleteProductFrame extends JFrame {
        JTextField productIdField;

        public DeleteProductFrame() {
            super("Delete Product");
            setSize(400, 100);
            setLocationRelativeTo(null);
            setLayout(new GridLayout(2, 2));

            productIdField = new JTextField();

            add(new JLabel("Product ID to delete:"));
            add(productIdField);

            JButton deleteButton = new JButton("Delete");
            deleteButton.addActionListener(e -> deleteProduct());
            add(deleteButton);
        }

        private void deleteProduct() {
            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
                int productId = Integer.parseInt(productIdField.getText());

                String sql = "DELETE FROM PRODUCTS1234 WHERE productid = ?";

                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setInt(1, productId);
                    int rowsAffected = pstmt.executeUpdate();
                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(this, "Product deleted successfully.");
                    } else {
                        JOptionPane.showMessageDialog(this, "Product not found.");
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    // Frame for retrieving products
    private class RetrieveProductsFrame extends JFrame {
        JTextArea outputArea;

        public RetrieveProductsFrame() {
            super("Retrieve Products");
            setSize(600, 400);
            setLocationRelativeTo(null);
            setLayout(new BorderLayout());

            outputArea = new JTextArea();
            outputArea.setEditable(false);
            add(new JScrollPane(outputArea), BorderLayout.CENTER);

            retrieveProducts();
        }

        private void retrieveProducts() {
            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
                String sql = "SELECT * FROM PRODUCTS1234";

                try (Statement stmt = conn.createStatement();
                     ResultSet rs = stmt.executeQuery(sql)) {

                    while (rs.next()) {
                        outputArea.append("Product ID: " + rs.getInt("productid") + "\n");
                        outputArea.append("Name: " + rs.getString("productname") + "\n");
                        outputArea.append("Category: " + rs.getString("category") + "\n");
                        outputArea.append("Quantity: " + rs.getInt("quantity") + "\n");
                        outputArea.append("Price: " + rs.getDouble("price") + "\n");
                        outputArea.append("Manufacture Date: " + rs.getDate("date_of_manufacture") + "\n");
                        outputArea.append("Expiry Date: " + rs.getDate("date_of_expiry") + "\n\n");
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    // Frame for updating products
    private class UpdateProductFrame extends JFrame {
        JTextField productIdField, quantityField;

        public UpdateProductFrame() {
            super("Update Product");
            setSize(400, 150);
            setLocationRelativeTo(null);
            setLayout(new GridLayout(3, 2));

            productIdField = new JTextField();
            quantityField = new JTextField();

            add(new JLabel("Product ID to update:"));
            add(productIdField);
            add(new JLabel("New Quantity:"));
            add(quantityField);

            JButton updateButton = new JButton("Update");
            updateButton.addActionListener(e -> updateProduct());
            add(updateButton);
        }

        private void updateProduct() {
            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
                int productId = Integer.parseInt(productIdField.getText());
                int newQuantity = Integer.parseInt(quantityField.getText());

                String sql = "UPDATE PRODUCTS1234 SET quantity = ? WHERE productid = ?";

                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setInt(1, newQuantity);
                    pstmt.setInt(2, productId);
                    int rowsAffected = pstmt.executeUpdate();
                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(this, "Product updated successfully.");
                    } else {
                        JOptionPane.showMessageDialog(this, "Product not found.");
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    // Frame for checking expired products
    private class CheckExpiredProductsFrame extends JFrame {
        JTextArea outputArea;

        public CheckExpiredProductsFrame() {
            super("Check Expired Products");
            setSize(600, 400);
            setLocationRelativeTo(null);
            setLayout(new BorderLayout());

            outputArea = new JTextArea();
            outputArea.setEditable(false);
            add(new JScrollPane(outputArea), BorderLayout.CENTER);

            checkExpiredProducts();
        }

        private void checkExpiredProducts() {
            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
                String sql = "SELECT * FROM PRODUCTS1234 WHERE date_of_expiry < CURDATE()";

                try (Statement stmt = conn.createStatement();
                     ResultSet rs = stmt.executeQuery(sql)) {

                    boolean foundExpiredProduct = false;

                    while (rs.next()) {
                        foundExpiredProduct = true;
                        outputArea.append("Expired Product ID: " + rs.getInt("productid") + "\n");
                        outputArea.append("Name: " + rs.getString("productname") + "\n");
                        outputArea.append("Expiry Date: " + rs.getDate("date_of_expiry") + "\n\n");
                    }

                    if (!foundExpiredProduct) {
                        outputArea.append("No expired products found.\n");
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductManagementApp().setVisible(true));
    }
}
