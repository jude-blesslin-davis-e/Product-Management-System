import java.sql.*;
import java.util.Scanner;

public class ProductMPDCanagementApp {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/shop_managemnet";
    private static final String USER = "root";
    private static final String PASS = "Jude2004@";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            System.out.println("Connected to the database");

            // Create a Scanner object to read input from the console
            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("\nMenu:");
                System.out.println("1. Insert Product");
                System.out.println("2. Delete Product");
                System.out.println("3. Retrieve Products");
                System.out.println("4. Update Product");
                System.out.println("5. Check Expired Products");
                System.out.println("6. Exit");
                System.out.print("Enter your choice: ");

                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        insertProduct(conn, scanner);
                        break;
                    case 2:
                        deleteProduct(conn, scanner);
                        break;
                    case 3:
                        retrieveProducts(conn);
                        break;
                    case 4:
                        updateProduct(conn, scanner);
                        break;
                    case 5:
                        checkExpiredProducts(conn);
                        break;
                    case 6:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice!");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void insertProduct(Connection conn, Scanner scanner) throws SQLException {
        System.out.print("Enter product name: ");
        String productName = scanner.nextLine();

        System.out.print("Enter category: ");
        String category = scanner.nextLine();

        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();

        System.out.print("Enter price: ");
        double price = scanner.nextDouble();

        System.out.print("Enter manufacture date (yyyy-mm-dd): ");
        String manufactureDate = scanner.next();

        System.out.print("Enter expiry date (yyyy-mm-dd): ");
        String expiryDate = scanner.next();

        String sql = "INSERT INTO PRODUCTS1234 (productname, category, quantity, price, date_of_manufacture, date_of_expiry) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, productName);
            pstmt.setString(2, category);
            pstmt.setInt(3, quantity);
            pstmt.setDouble(4, price);
            pstmt.setDate(5, Date.valueOf(manufactureDate));
            pstmt.setDate(6, Date.valueOf(expiryDate));
            pstmt.executeUpdate();

            // Retrieve the generated productid
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    System.out.println("Product inserted successfully. Product ID: " + generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Failed to get the productid.");
                }
            }
        }
    }

    private static void deleteProduct(Connection conn, Scanner scanner) throws SQLException {
        System.out.print("Enter product ID to delete: ");
        int productId = scanner.nextInt();

        String sql = "DELETE FROM PRODUCTS1234 WHERE productid = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, productId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Product deleted successfully.");
            } else {
                System.out.println("Product not found.");
            }
        }
    }

    private static void retrieveProducts(Connection conn) throws SQLException {
        String sql = "SELECT * FROM PRODUCTS1234";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println("Product ID: " + rs.getInt("productid"));
                System.out.println("Name: " + rs.getString("productname"));
                System.out.println("Category: " + rs.getString("category"));
                System.out.println("Quantity: " + rs.getInt("quantity"));
                System.out.println("Price: " + rs.getDouble("price"));
                System.out.println("Manufacture Date: " + rs.getDate("date_of_manufacture"));
                System.out.println("Expiry Date: " + rs.getDate("date_of_expiry"));
                System.out.println();
            }
        }
    }

    private static void updateProduct(Connection conn, Scanner scanner) throws SQLException {
        System.out.print("Enter product ID to update: ");
        int productId = scanner.nextInt();

        System.out.print("Enter new quantity: ");
        int newQuantity = scanner.nextInt();

        String sql = "UPDATE PRODUCTS1234 SET quantity = ? WHERE productid = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, newQuantity);
            pstmt.setInt(2, productId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Product updated successfully.");
            } else {
                System.out.println("Product not found.");
            }
        }
    }

    private static void checkExpiredProducts(Connection conn) throws SQLException {
        String sql = "SELECT * FROM PRODUCTS1234 WHERE date_of_expiry < CURDATE()";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean foundExpiredProduct = false;

            while (rs.next()) {
                foundExpiredProduct = true;
                System.out.println("Expired Product ID: " + rs.getInt("productid"));
                System.out.println("Name: " + rs.getString("productname"));
                System.out.println("Expiry Date: " + rs.getDate("date_of_expiry"));
                System.out.println();
            }

            if (!foundExpiredProduct) {
                System.out.println("No expired products found.");
            }
        }
    }

}
